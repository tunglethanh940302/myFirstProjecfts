#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define FILENAME "log.txt"
#define MAXLEGHTHFILE 5000

char fileStr[MAXLEGHTHFILE];

int fileToStr (char* str){
    int status;
    FILE *fp = NULL;

    fp = fopen(FILENAME, "r");
    if (fp == NULL){
        printf("File does not exits\n");
        return -1;
    }
    status = fread(str, MAXLEGHTHFILE, 1, fp);

   // printf("Noi dung cua file log.txt: \n%s", str);
    fclose(fp);
    fp == NULL;
    return status;
}


void soBanTinGuiDi(){

    fileToStr(fileStr);

    int i = 0;
    char* token = strtok(fileStr,"\n");         //Tach chuoi thanh cac token phan biet

    while(token != NULL){
        char* str1 = strstr(token, "\"cmd\":\"set\"");  //kiem tra chuoi "cmd":"set" co xuat hien khong
        if(str1 != NULL){
            i++;                                      // tang bien dem
            printf("%s\n",token);                   // in ket qua raman hinh
        }
        token = strtok(NULL, "\n");               // tiep tuc tach chuoi
    }
    printf("\n--------------------------------------------------\n");
    printf("\tSo ban tin gui di: %d\n",i);
}
// Tinh so ban tin gui di tu thiet bi

void soBanTinTuThietBi(){

    fileToStr(fileStr);

    int count = 0;      // tao bien dem
    char nwk[10];       // mang chua ten thiet bi nhap tu ban phim
    printf("Nhap dia chi NWK cua thiet bi :\n");
    scanf("%s", nwk);

    char tenThietbi[] = "zwave-";       // mang chua ten thiet bi
    strcat(tenThietbi, nwk);            // noi zwave- voi ten thiet bi nhap tu ban phim va luu vao mang tenThietBi


    char* token = strtok(fileStr,"\n"); // chia fileStr thanh cac token rieng biet

    while(token != NULL){
        char* guiDi_search = strstr(token, "\"cmd\":\"set\"" );         // kiem tra "cmd:set" co xuat hien trong chuoi khong

        char* nwk_search = strstr(token, tenThietbi);           // kiem tra ten thiet bi co xuat hien trong chuoi hay khong

        if(guiDi_search != NULL && nwk_search != NULL){     // neu "cmd:set" va ten thiet bi xuat hien trong chuoi thi
            count++;                                        // tang bien dem
            printf("%s\n",token);                           // xuat ra man hinh
        }

        token = strtok(NULL, "\n");                         // tiep tuc tach chuoi
    }
    printf("\nSo ban tin gui di tu thiet bi %s la :%d\n", tenThietbi, count);  // tong so ban tin gui di
}

void slDiaChiCongTac(){

	fileToStr(fileStr);

	int i = 0, j;
	char network[20][10];       //mang 2 chieu luu tru ten network
	char endPoint[2];           // mang endPoint luu tru endpoint
    char temp[5];

	char *token = strtok(fileStr,"\n");         // tach chuoi thanh cac token phan biet

	while (token != NULL){
		if(strstr(token,"\"cmd\":\"set\"") != NULL && strstr(token, "\"type\":\"switch\"") != NULL) {  //chuoi co xuat hien "cmd:set" va "type":"switch"

			char* zwave = strstr(token, "zwave-");      // con tro zwave tro toi vi tri zwave- trong chuoi
            bool flag = false;                          // tao bien boolean flag va gan gia tri false

			strncpy(temp, zwave+6, 4);                  // coppy 4 ky tu tinh tu vi tri con tro zwave + 6 gan vao mang temp
			temp[4]='\0';                               // ket thuc chuoi bang cach gan ky tu thu 4 cua mang = '\0'

			for(j=0; j<i; j++){
			    if(strcmp(temp,network[j]) == 0)        // kiem tra temp co xuat hien trong mang network hay chua
				flag = true;                            // neu co roi thi gan flag = true
			}
			if(flag == false){
				strcpy(network[i], temp);               // coppy chuoi temp vao network
				strncpy(&endPoint[i], zwave+13, 1);     // coppy 1 ky tu tinh tu vi tri con tro zwave + 13 vao dia chi endPoint[i] (zwave-dc53:4-1)
				i++;                                    // tang bien dem
			}
		}
		token = strtok(NULL, "\n");                     // tiep tuc tach chuoi
	}

	for(j=0; j<i; j++){
		printf("\nThiet bi %d co dia chi la: NWK - %s, ENDPOINT - %c\n",j+1, network[j], endPoint[j]);
	}

}

void banTinBiLoi(){

    fileToStr(fileStr);

    char temp1[5];
    char temp2[5];

    int count = 0;

    char* token = strtok(fileStr,"\n");         // tach chuoi thanh cac token phan biet

    while(token != NULL){

        char* reqid = strstr(token,"\"reqid\"");    // tra ve con tro tro den vi tri "requid"

        if (strstr(token,"\"cmd\":\"set\"") != NULL) {      // token co xuat hien "cmd":"set"
            strncpy(temp1, reqid+10, 4);        // luu gia tri sau requid vao temp1   "reqid": "0001"
        }
        token = strtok(NULL, "\n");             // tiep tuc tach chuoi

        char* reqid1 = strstr(token,"\"reqid\"");   // tra ve con tro tro den vi tri "requid"

        if (strstr(token,"\"cmd\":\"status\"") != NULL) {       // token co xuat hien "cmd":"status"
            strncpy(temp2, reqid1+10, 4);       // luu gia tri sau requid vao temp2
        }
        token = strtok(NULL, "\n");             // tiep tuc tach chuoi

        if (strcmp(reqid, reqid1) != 0) {       // so sanh 2 chuoi requid va requid1
            count++;                            // tang bien dem
        }
    }
    printf("\nSo ban tin loi: %d\n", count);
}

void doTreLonNhat(){

    fileToStr(fileStr);

    long time, time1, delay = 0;                    // khai bao cac bien can thiet
    char* token = strtok(fileStr,"\n");             // tach chuoi thanh cac token phan biet

    while (token != NULL) {

        char* pToken1 = strstr(token, ":");         // con tro pToken1 tro den vi tri xuat hien dau tien cua dau :
        char* reqid1 = strstr(token, "\"reqid\"");   // con tro eqid1 tro den vi tri xuat hien dau tien cua chuoi "reqid"
        char reqidStr[5];

        strncpy(reqidStr, reqid1+10, 4);            // "reqid": "0001" coppy 4 phan tu ke tu phan tu thu 10 sau vi tri con tro reqid1 (o day la 0001)
        char hour[3], minute[3], second[7];
        token = strtok(NULL, "\n");                 // tiep tuc tach chuoi

        char* pToken2 = strstr(token, ":");
        char* reqid2 = strstr(token, "\"reqid\"");
        char reqidStr1[5];

        strncpy(reqidStr1, reqid2+10, 4);
        char hour2[3], minute2[3], second2[7];
        token = strtok(NULL, "\n");

        if(strcmp(reqidStr, reqidStr1) == 0){       // neu reqidStr va reqidStr1 bang nhau co nghia la ban tin gui thanh cong
            strncpy(hour, pToken1-2, 2);            // [2019-10-2323:21:45.638] pos -2 truoc dau : 2 so
            strncpy(minute, pToken1+1, 2);          // pToken + 1 sau dau : 1 so
            strncpy(second, pToken1+4, 6);          // pToken + 4 sau dau : 4 so
            hour[2] = '\0';                         // ket thuc chuoi
            minute[2] = '\0';
            second[6] = '\0';

            time = atof(hour)*3600000 + atof(minute)*60000 + atof(second)*1000;     // ham atof() chuyen doi mang hour, minute, second sang dang so thuc float

            strncpy(hour2, pToken2-2, 2);
            strncpy(minute2, pToken2+1, 2);
            strncpy(second2, pToken2+4, 6);
            hour2[2] = '\0';                        // ket thuc chuoi
            minute2[2] = '\0';
            second2[6] = '\0';

            time1 = atof(hour2)*3600000 + atof(minute2)*60000 + atof(second2)*1000; // 1 second = 1000 miliseconds

            if((time1 - time) > delay){
                delay = time1 - time;                   // so sanh va luu gia tri vao delay
            }
        }
    }
    printf("\nDo tre lon nhat la: %d Milliseconds", delay);
}

void doTreTrungBinh(){

    fileToStr(fileStr);
    int count = 0;
    long time, time1, delay = 0, totalDelay = 0, avgDelay = 0;                    // khai bao cac bien can thiet
    char* token = strtok(fileStr,"\n");             // tach chuoi thanh cac token phan biet

    while (token != NULL) {

        char* pToken1 = strstr(token, ":");         // con tro pToken1 tro den vi tri xuat hien dau tien cua dau :
        char* reqid1 = strstr(token, "\"reqid\"");   // con tro eqid1 tro den vi tri xuat hien dau tien cua chuoi "reqid"
        char reqidStr[5];

        strncpy(reqidStr, reqid1+10, 4);            // "reqid": "0001" coppy 4 phan tu ke tu phan tu thu 10 sau vi tri con tro reqid1 (o day la 0001)
        char hour[3], minute[3], second[7];
        token = strtok(NULL, "\n");                 // tiep tuc tach chuoi

        char* pToken2 = strstr(token, ":");
        char* reqid2 = strstr(token, "\"reqid\"");
        char reqidStr1[5];

        strncpy(reqidStr1, reqid2+10, 4);
        char hour2[3], minute2[3], second2[7];
        token = strtok(NULL, "\n");

        if(strcmp(reqidStr, reqidStr1) == 0){       // neu reqidStr va reqidStr1 bang nhau co nghia la ban tin gui thanh cong
            strncpy(hour, pToken1-2, 2);            // [2019-10-2323:21:45.638] pos -2 truoc dau : 2 so
            strncpy(minute, pToken1+1, 2);          // pToken + 1 sau dau : 1 so
            strncpy(second, pToken1+4, 6);          // pToken + 4 sau dau : 4 so
            hour[2] = '\0';                         // ket thuc chuoi
            minute[2] = '\0';
            second[6] = '\0';

            time = atof(hour)*3600000 + atof(minute)*60000 + atof(second)*1000;     // ham atof() chuyen doi mang hour, minute, second sang dang so thuc float

            strncpy(hour2, pToken2-2, 2);
            strncpy(minute2, pToken2+1, 2);
            strncpy(second2, pToken2+4, 6);
            hour2[2] = '\0';                        // ket thuc chuoi
            minute2[2] = '\0';
            second2[6] = '\0';

            time1 = atof(hour2)*3600000 + atof(minute2)*60000 + atof(second2)*1000; // 1 second = 1000 miliseconds

            totalDelay += time1 - time;             // tinh tong thoi gian delay
            count++;                                // so cap ban tin duoc tinh toan
        }
    }
    avgDelay = totalDelay/count;                    // tinh do tre trung binh
    printf("\nDo tre trung binh la: %d Milliseconds", avgDelay);
}


int main(){

    printf("\n--------------------------------------------------\n");
    soBanTinGuiDi();
    printf("\n--------------------------------------------------\n");
    slDiaChiCongTac();
    printf("\n--------------------------------------------------\n");
    banTinBiLoi();
    printf("\n--------------------------------------------------\n");
    soBanTinTuThietBi();
    printf("\n--------------------------------------------------\n");
    doTreTrungBinh();
    printf("\n--------------------------------------------------\n");
    doTreLonNhat();
    printf("\n--------------------------------------------------\n");

    return 0;
}

