import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Algorithm {				
	
	public static float[] inputArray (Scanner sc, float[] arr) {					// ham inputArray dung de nhap mang 
		System.out.print("Nhap so luong phan tu: ");
		int n = sc.nextInt();														// khai bao so luong phan tu cua mang
		arr = new float[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.print((i+1) + ": ");
			arr[i] = sc.nextFloat();												// nhap tung phan tu cua mang dung vong lap for
		}
		return arr;																	// ham tra ve mang arr duoc nguoi dung nhap
	}
	public static void writeFile(String fileName, float[] arr) {					// ham writeFile ghi noi dung cua mang vao file
		try {																		// su dung try-catch de bat loi 	
			File file = new File(fileName);											// tao doi tuong file moi 
			PrintWriter pw = new PrintWriter(file);									// tao doi tuong printwriter pw
			int n = arr.length;									
			pw.print("" + n + "\n");												// ghi do dai mang arr vao file
			for (int i = 0; i < n; i++) {											
				pw.print(" " + arr[i]);												// su dung vong lap for de ghi gia tri tung phan tu cua mang arr vao file				
			}
			pw.flush();																
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void readArray(float[] arr) {										// ham readArray de doc mang 
		for (int i = 0; i < arr.length; i++) {										// dung vong lap for duyet tung phan tu trong mang va xuat ra man hinh
			System.out.print(" " + arr[i]);
		}
	}
	public static float[] readFile(String fileName, float a[]){						// ham readFile de doc file voi 2 doi so nhap vao la chuoi luu tru fileName va 1 mang a[]	
		File file = new File(fileName);												// khoi tao File va Scanner		
		Scanner sc = null;
		try {																		// dung try-catch de bat loi
			sc = new Scanner(file);
			int n = sc.nextInt();													// doc gia tri so nguyen duoc luu trong file va luu vao bien n (day chinh la do dai cua mang ngoi dung nhap vao )
			a = new float[n];														
			int i=0;
			while (sc.hasNextFloat()) {												// luu lan luot tung gia tri so thuc trong file  vao mang a 
				a[i] = sc.nextFloat();
				i++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}

	public static void printArray (int no, float[] a) 								// ham printArray dung de in mang		
	{	
		System.out.print((no+1) + ": ");											// dung vong lap for duyet tung phan tu trong mang va in ra man hinh 
		for (int i = 0; i < a.length; i++) {												
			System.out.print(a[i] + " ");
		}
		System.out.println();
	}
	
	public static float[] bubbleSort(float[] a) 									// thuat toan bubbleSort
	{
		System.out.println("Bubble sort");
		int n = a.length;															
		float[] b = new float[n];													// khai bao 1 mang b moi
		for (int i = 0; i < n; i++) {												// dung vong lap for de copy mang a vao mang b 
			b[i] = a[i];
		}
		for (int i = 0; i < n; i++) {												// su dung 2 vong lap for long nhau de  sap xep
			boolean isSorted = true;												// khai bapo bien boolean isSorted	va khoi tao gia tri true
			for (int j = 0; j < n-i-1; j++) {
				if (b[j] > b[j+1]) {												// neu gia tri tai vi tri j > gia tri tai vi tri i thi thuc hien hoan doi vi tri 
					isSorted = false;												// gan isSorted = false
					float temp = b[j];
					b[j] = b[j+1];
					b[j+1] = temp;
				}
			}
			printArray(i, b);														// dung ham printArray de in tung buoc sap xep
			if (isSorted) 															// neu mang da duoc sap xep  thi ket thuc vong lap
				break;
																			
		}
		return b;																	// ham tra ve mang b da duoc sap xep
	}
	
	public static float[] insertionSort (float[] a) 								// thuat toan insertionSort
	{
		int n = a.length;
		float[] b = new float[n];
		for (int i = 0; i < n; i++) {												// sao chep mang a vao mang b		
			b[i] = a[i];
		}
		System.out.println("Insertion sort");
		for (int i = 1; i < n; i++) {
			float bi = b[i];														// khai bao bien bi luu tru gia tri tai bi tri i
			int j = i-1;															// khoi tao j = i-1				
			while (j >= 0 && b[j] > bi)												// xet mang con ben trai ohan tu thu i ( b[i] )
			{																		// neu j >= 0 va b[j] > bi thi doi b[j] lui ve sau 1 don vi 
				b[j+1] = b[j];														// giam bien j 
				j--;
			}
			b[j+1] = bi;															// gan b[j+1] = bi
			printArray((i-1), b);													// dung ham printArray in tung buoc sap xep
		}
		return b;																	// ham tra ve mang b da doc sap xep	
	}
	public static float[] selectionSort (float[] a)									// thuat toan sap xep selectionSort
	{
		int n = a.length;
		float[] b = new float[n];
		for (int i = 0; i < n; i++) {												// sao chep mang a vao mang b
			b[i] = a[i];
		}
		System.out.println("Selection sort");
		for (int i = 0; i < n; i++) {											
			int minIndex = i;
			for (int j = i+1; j < n; j++) {											// su dung vong lap for de tim vi tri index co gia tri < vi tri minIndex
				if(b[j] < b[minIndex]) {
					minIndex = j;													// gan minIndex = j												
				}
			}
			if (minIndex != i)														// neu tim thay vi tri co gia tri nho hon vi tri minIndex  
			{
				float temp = b[i];													// thuc hien hoan doi 
				b[i] = b[minIndex];
				b[minIndex] = temp;
			}
			printArray(i, b);
		}
		return b;																	// ham tra ve mang b da duoc sap xep
	}
	public static void search (float[] a, float value) {							// ham search tim kiem phan tu > value co trong mang a
		int n = 0;
		try {
			File file = new File("OUTPUT4.TXT");									// tao File moi
			PrintWriter pw = new PrintWriter(file);									// tao printWriter moi		
			for (int i = 0; i < a.length; i++) {									// su dung vong lap for duyet tung phan tu trong mang
				if (a[i] > value) {													// neu phan tu tai vi tri i > value 		
					System.out.print(i + " ");										// xuat i ra man hinh
					pw.print(" " + i);												// luu i vao file OUTPUT4.TXT
					n++;															// tang bien n
					pw.flush();
				}
			}
			pw.print("\n" + n);														// luu n vao file
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println();		
	}
	public static void writeFileCh (String fileName, int i) {						// ham writeFileCh	de ghi so nguyen i vao file
		try {
			File file = new File(fileName);
			PrintWriter pw = new PrintWriter(file);
			pw.print(i);
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public static int binarySearch(float[] arr, int left, int right, float value) {		// ham binarySearch tim kiem nhi phan
//		if (right >= left) {
//			int mid = (left + (right-left)) / 2;
//			if (arr[mid] == value) 														// neu phan tu co o chinh giua
//				return mid;																// tra ve vi tri mid
//			if (arr[mid] > value)														// neu phan tu nho hon phan tu o giua
//				return binarySearch(arr, left, mid-1, value);							// thi tim kiem o mang con ben trai
//			return binarySearch(arr, mid, right+1, value); 							// nguoc lai tim kiem o mang con ben phai
//		}
		while (left <= right) {
			int mid = (left+right)/2;
			if (arr[mid] == value) {
				return mid;
			} else if (arr[mid] > value) {
				right = mid -1;
			} else {
				left = mid + 1;
			}		
		}
		return -1;															// neu phan tu khong co trong mang thi return -1
	}
	public static void runTime (long time) {											// ham runTime the hien thoi gian chay cua chuong trinh
		long t5 = System.currentTimeMillis();											// khai bao bien t5 luu tru thoi gian hien tai
		System.out.println("Time: " + (t5-time));										// thoi gian chay cua chuong trinh t5-thoi gian truoc khi chuong trinh chay	
	}
}
