import java.util.Scanner;

public class MainSort {
	
	public static void main(String[] args) {								// ham main dieu khien chuong trinh
		Scanner sc = new Scanner(System.in);								// tao doi tuong Scanner
		float[] a = null;													// tao mang float a
		int choice;															// bien choice luu lua con cua nguoi dung	
		do {																// su dung vong lap do-while de thuc thi chuong trinh		
			System.out.println("+-------------------MENU------------------+");	// tao MENU
			System.out.println("|          1.Input                        |");
			System.out.println("|          2.Output                       |");
			System.out.println("|          3.Bubble sort                  |");
			System.out.println("|          4.Selection sort               |");
			System.out.println("|          5.Insertion sort               |");
			System.out.println("|          6.Search > value               |");
			System.out.println("|          7.Search = value               |");
			System.out.println("|          0.Exit                         |");
			System.out.println("+-----------------------------------------+");
			choice = sc.nextInt();
			switch (choice) {														// su dung switch-case de dieu khien chuong trinh
			case 0:
				System.out.println("THANKS!!!");									// nguoi dung chon 0 >>>> thoat
				break;
			case 1:																	// nguoi dung chon 1 >>>> chay ham inputArray va ghi vao file bang ham writeFile
				a = Algorithm.inputArray(sc, a);
				Algorithm.writeFile("INPUT.TXT", a);
				break;
			case 2:
				System.out.print("Array a:");
				a = Algorithm.readFile("INPUT.TXT", a);								// nguoi dung chon 2 >>>> doc file INPUT va luu vao mang a
				Algorithm.readArray(a);												// in mang a ra man hinh 
				System.out.println();
				break;
			case 3:																	// nguoi dung chon 3 >>>>
				a = Algorithm.readFile("INPUT.TXT", a);								// doc file INPUT va luu vao mang a
				System.out.println();	
				long t0 = System.currentTimeMillis();								// khai bao bien t0 luu tru thoi gian hien tai
				Algorithm.writeFile("OUTPUT1.TXT", Algorithm.bubbleSort(a));		// thuc hien sap xep bubble Sort va luu vao file OUTPUT1.TXT
				Algorithm.runTime(t0);												// tinh thoi gian chay cua chuong trinh
				break;	
			case 4:																	// nguoi dung chon 4 >>>>	
				a = Algorithm.readFile("INPUT.TXT", a);								// doc file INPUT va luu vao mang a	
				System.out.println();
				long t1 = System.currentTimeMillis();								// khai bao bien t1 luu tru thoi gian hien tai
				Algorithm.writeFile("OUTPUT2.TXT", Algorithm.selectionSort(a));		// thuc hien sap xep selection Sort va luu vao file OUTPUT2.TXT
				Algorithm.runTime(t1);												// tinh thoi gian chay cua chuong trinh
				break;
			case 5:																	// nguoi dung chon 5 >>>>
				a = Algorithm.readFile("INPUT.TXT", a);								// doc file INPUT va luu vao mang a	
				System.out.println();
				long t2 = System.currentTimeMillis();								// khai bao bien t2 luu tru thoi gian hien tai
				Algorithm.writeFile("OUTPUT3.TXT", Algorithm.insertionSort(a));		// thuc hien sap xep insertion Sort va luu vao file OUTPUT3.TXT
				Algorithm.runTime(t2);												// tinh thoi gian chay cua chuong trinh
				break;
			case 6:																	// nguoi dung chon 6 >>>>
				a = Algorithm.readFile("INPUT.TXT", a);								// doc file INPUT va luu vao mang a	
				System.out.println();
				System.out.print("Nhap so can tim: ");								// nhap so can tim
				float num = sc.nextFloat();
				System.out.print("Chi so la: ");
				Algorithm.search(a, num);											// chay ham search 
				break;	
			case 7:																	// nguoi dung chon 7 >>>>
				a = Algorithm.readFile("INPUT.TXT", a);								// doc file INPUT va luu vao mang a
				a = Algorithm.bubbleSort(a);
				int n = a.length;	
				System.out.print("Nhap so can tim: ");
				float num1 = sc.nextFloat();
				int i = Algorithm.binarySearch(a, 0, n-1, num1);					// thuc hien tim kiem chay ham binaruSearch
				if (i == -1)
					System.out.println("Khong ton tai so can tim");
				else
					System.out.println("Chi so cua phan tu: " + i);						// hien thi vi tri tim thay
				Algorithm.writeFileCh("OUTPUT5.TXT", i);							// luu ket qua vao file OUTPUT5.TXT
				break;
			default:
				break;
			}
		}while (choice != 0);
	}
}
