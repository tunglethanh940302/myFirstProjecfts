bài asm1 em có nhờ mentor xem giùm bài của em xem có lỗi hay không thì mentor trả lời như sau:

 
Mình là mentor vừa có phiên hỏi đáp với bạn trên hf.
Sau khi cài Code::Blocks và chạy code của bạn bằng cách import project,
chọn file .cbp trong thư mục ở file zip thì thấy vẫn chạy được và không hề có lỗi. 
Bạn vui lòng viết trong file readme hướng dẫn cách import project và báo mentor chấm bài
chạy lại file nhé.

Best regards,
Tieugiang.

bài asm3 này em cũng mong mentor xem xét lỗi này giúp em  với ạ,
em cám ơn.