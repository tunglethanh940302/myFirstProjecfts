
public interface ICalculator {
	// interface ICalculator chua ham tinh luong
	// cac class Employee, Manager, Staff implements ICalculator 
	public int tinhLuong();

}
