// import goi thu vien java.util.Random
// khai bao Random
import java.util.Random;

import java.util.Scanner;

public class LuckyNumber {
	static int totalGuess = 0, totalGames = 0, bestGame = 102, guess = 0, max = 101;
	static float guessAvg;

	// ham play thuc hien tro choi	
	/*
	 * su dung bong lap do-while de cho nguoi choi du doan 
	 * neu nguoi choi du doan sai thi tiep tuc thuc hien do
	 * neu nguoi choi du doan dung thi thong bao du doan dung voi so lan du doan
	 */
	public static void play(int number) {	
		
			System.out.println("Toi dang nghi 1 con so tu 0 den 100...");
			Scanner sc = new Scanner(System.in);
			int userNumber = 102;
			do {
				System.out.print("ban doan? ");		
				userNumber = sc.nextInt();		
				if (userNumber > number) {
					guess++;
					System.out.println("So may man nho hon so du doan cua ban");
				} else if (userNumber < number) {
					guess++;
					System.out.println("So may man lon hon so du doan cua ban");
				}
			} while (userNumber != number);
			 
			guess++;			// tang bien dem guess
			totalGames++;		// tang bien dem totalGames
			System.out.println("Chuc mung!!! Ban da du doan dung con so may man");
			System.out.println("So lan du doan: "+ guess);
	}
	
	// ham report hien thi bao cao	
	public static void report() {
		System.out.println("Ket qua tong quat cua tro choi:");
		System.out.println("Tong so lan choi = "+ totalGames);
		System.out.println("Tong so lan du doan = "+ totalGuess);
		System.out.println("So lan du doan trung binh moi luot = "+ guessAvg);
		System.out.println("So lan du doan it nhat = "+ bestGame);
	}
	
	
	//ham main dieu khien chuong trinh
	
	public static void main(String[] args) {
		Random rd = new Random();   // khai bao 1 doi tuong Random
	    Scanner sc = new Scanner(System.in);
	    String yes = "yes";
	    String y = "y";
	    String next;
	    /* su dung vong lap do-while de thuc hien chuong trinh
	     * neu nguoi choi muon tiep tuc thi se duoc tiep tuc choi
	     * dieu kien de tiep tuc choi la nguoi dung nhap vao "y" hoac "yes" khong phan biet chu hoa chu thuong
	     */
	    do {				
		    int number = rd.nextInt(max);  // tra ve 1 so nguyen tu 0 den max
		    System.out.println("So vua duoc sinh ra la: " + number);
	    	play(number);  
		    System.out.print("Ban co muon tiep tuc choi khong? ");
		    next = sc.nextLine();
		    if (guess < bestGame)
		    	bestGame = guess;
		    totalGuess = totalGuess + guess;
		    guess = 0;
		    System.out.println("-------------------------------");
	    } while (next.equalsIgnoreCase(y) || next.equalsIgnoreCase(yes));
	    
	    guessAvg = (float)totalGuess/totalGames;	  // tinh trung binh  
	    report();	    								// goi ham report()
	    sc.close();    
	}
}
