import java.util.Scanner;

public class GradeStudent {

	/* 
	 * Khoi tao cac bien can thiet
	 */
	static float weightScore, finalWeightedScore, hwWeightedScore, gradeScore;
	static int weight, finalWeight, hwWeight;

	// ham begin() hien thi thong diep chao mung
	public static void begin() {
		System.out.println("This program reads exam/homework scores and reports your overall course grade.");
	}
	
	//ham midTerm() nhap va tinh toan diem thi giua ky
	public static void midTerm() {
		int plusScore, scores, scoresShifted, totalPoints;		// khoi tao cac bien cacn thiet
		
		Scanner sc = new Scanner(System.in); 	// khoi tao doi tuong Scanner
		System.out.println("Midterm:");
		System.out.print("Weight (0-100)? ");	
		weight = sc.nextInt();					// nhap trong so
		System.out.print("Score earned? ");		
		scores = sc.nextInt();					// nhap diem dat duoc
		System.out.print("Were scores shifted (1=yes, 2=no)? ");		// co duoc cong them diem hay khong? 1 = co 2 = khong.
		scoresShifted = sc.nextInt();
		
		if (scoresShifted == 1) {				// phan chia cac truong hop 1 va 2 bang cau lenh if-else 
			System.out.print("Add points: ");	// neu scoresShifted == 1 thi yeu cau nhap so diem cong them va tinh tong diem
			plusScore = sc.nextInt();
			totalPoints = scores + plusScore;
		} else {								// neu scoresShifted == 2 thi tong diem = diem dat duoc
			totalPoints = scores;
		}
		if (totalPoints > 100)		// tong diem toi da la 100
			totalPoints = 100;
		System.out.println("Total points =  "+ totalPoints + " / 100");
		
		weightScore = (float)(totalPoints / 100.0 * weight);   		// tinh trung binh va lam tron den chu so thap phan thu 1
		weightScore = (float)(Math.round(weightScore * 10)) / 10;

		System.out.println("Weighted score = "+ weightScore + " / "+ weight);
		
	}
	
	//ham finalTerm() de nhap va tinh toan diem thi cuoi ky
	public static void finalTerm() {
		int finalScore, finalScoreShifted, finalShiftAmount, finalTotalPoints;		// khoi tao cac bien can thiet
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Final:");
		System.out.print("Weight (0-100)? ");	
		finalWeight = sc.nextInt();				// nhap vao trong so
		System.out.print("Score earned? ");		
		finalScore = sc.nextInt();				// nhap vao so diem dat duoc
		System.out.print("Were scores shifted (1=yes, 2=no)? ");	
		finalScoreShifted = sc.nextInt();		
		if (finalScoreShifted == 1) {			// phan chia cac truong hop 1 va 2 bang cau lenh if-else 
			System.out.print("Shift amount? ");	// neu finalScoresShifted == 1 thi yeu cau nhap so diem cong them va tinh tong diem
			finalShiftAmount = sc.nextInt();
			finalTotalPoints = finalScore + finalShiftAmount;
		} else {								// // neu scoresShifted == 2 thi tong diem = diem dat duoc
			finalTotalPoints = finalScore;
		}
		if (finalTotalPoints > 100)		// tong diem toi da la 100
			finalTotalPoints = 100;
		System.out.println("Total points =  "+ finalTotalPoints + " / 100");
		
		finalWeightedScore = (float)(finalTotalPoints / 100.0 * finalWeight);	//tinh diem trung binh va lam tron den 1 chu so thap phan
		finalWeightedScore = (float)Math.round(finalWeightedScore * 10) / 10;

		System.out.println("Weighted score = "+ finalWeightedScore + " / "+ finalWeight);
		
	}
	
	//ham homework() nhap va tinh toan diem bai tap ve nha
	
	public static void homework() {

		int numOfAsm, numOfSections, sectionPoints; // khai bao cac bien can thiet
		int asmMaxPoints = 0;
		int hwTotalPoints = 0;
		Scanner sc = new Scanner(System.in); // khoi tao Scanner sc
		
		System.out.println("Homework:");
		do {												// su dung vong lap do-while de kiem tra dieu kien tong cac trong so phai la 100
			System.out.print("Weight (0-100)? ");	
			hwWeight = sc.nextInt();
		}while ((hwWeight + weight + finalWeight) != 100);  // dieu kien tong cac trong so phai la 100
		
		// yeu cau nhap so diem va diem asm toi da va luu vao cac mang asm1 asm2 asm3 tuong ung
		
		System.out.print("Number of assignments? ");	
		numOfAsm = sc.nextInt();
		
		int[][] asm = new int[numOfAsm][2];		// tao mang 2 chieu de luu diem asm. 
		for(int i=0; i<numOfAsm; i++) {			// su dung vong lap for de nhap diem va diem toi da cua asm
			System.out.print("Assignment "+ (i+1) + " score and max? ");	
			for (int j=0; j<2; j++) {	
				asm[i][j] = sc.nextInt();		// lan luot nhap diem va diem toi da cua asm
			}
		}
		
		System.out.print("How many sections did you attend? ");		// hoi nguoi dung so buoi da diem danh
		numOfSections = sc.nextInt();								// nhap so buoi da diem danh
		sectionPoints = numOfSections * 5;							// diem section tinh bang so buoi da diem danh * 5
		if (sectionPoints > 30)
			sectionPoints = 30;  									// diem attend toi da la 30
		System.out.println("Section points = "+ sectionPoints+ " / 30");		// xuat ra man hinh ket qua
		
		for (int i=0; i<numOfAsm; i++) {							// su dung vong lap for de tinh tong diem bai tap
				hwTotalPoints += asm[i][0]; 						// diem asm cua hoc sinh duoc luu o vi tri dau tien trong cac mang con asm[i][0]
		}
		hwTotalPoints += sectionPoints;								// hoc sinh se duoc cong them diem attend
		if (hwTotalPoints > 150)									
			hwTotalPoints = 150;									// tong diem toi da la 150 
		for (int i=0; i<numOfAsm; i++) {							// su dung vong lap for de tinh tong diem toi da cua cac asm 
			asmMaxPoints += asm[i][1]; 								// diem toi da cua tung asm la gia tri cua phan tu thu 2 trong cac mang con asm[i][1]
		}
		asmMaxPoints += 30;													
		if(asmMaxPoints > 150) 
			asmMaxPoints = 150;										// diem toi da cua cac asm la 150
		System.out.println("Total points = "+ hwTotalPoints + " / "+ asmMaxPoints);
		
		hwWeightedScore = (float)hwTotalPoints  * hwWeight / asmMaxPoints;		// tinh trung binh va lam tron den 1 chu so thap phan
		hwWeightedScore = (float)(Math.round(hwWeightedScore*10)) / 10;
		System.out.println("Weighted score = "+ hwWeightedScore + " / "+ hwWeight );
		
	}
	/*
	 *  ham grade()
	 *  ham tra ve gia tri float la tong cua 3 doi so float nhap vao
	 */
	public static float grade(float midTerm, float fn, float hw) {
		return midTerm + fn + hw;
	}
	
	/* ham report() de tinh toan va hien thi ket qua GPA va dua ra nhan xet tuong ung
	 * goi ham grade() voi doi so nhap vao la weightScore, hwWeightedScore, finalWeightedScore
	 * su dung cau lenh if-else de phan chia tung truong hop cu the va xuat ra man hinh
	 */
	public static void report() {
		float gpa;
		gradeScore = grade(weightScore, hwWeightedScore, finalWeightedScore);
		System.out.println("Overall percentage = "+ gradeScore);
		
		if (gradeScore >= 85) {
			gpa = 3.0f;
			System.out.println("Your grade will be at least: " +gpa);
			System.out.println("<< Very Good >>");
		} else if (gradeScore >= 75 && gradeScore < 85) {
			gpa = 2.0f;
			System.out.println("Your grade will be at least: " + gpa);
			System.out.println("<< Good >>");
		} else if (gradeScore >= 60 && gradeScore < 75){
			gpa = 1.0f;
			System.out.println("Your grade will be at least: " +gpa);
			System.out.println("<< Must try harder >>");
		} else {
			gpa = 0.0f;
			System.out.println("Your grade will be at least: " +gpa);
			System.out.println("<< So bad >>");
		}
	}
	
	/* ham main thuc thi chuong trinh
	 * goi lan luot cac ham begin() - midTerm() - finalTerm() - homework() - report()
	 */
	public static void main(String[] args) {
		
		begin();
		System.out.print("\n");
		midTerm();
		System.out.print("\n");
		finalTerm();
		System.out.print("\n");
		homework();
		System.out.print("\n");
		report();
		
	}

}
