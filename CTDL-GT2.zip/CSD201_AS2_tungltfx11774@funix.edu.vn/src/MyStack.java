
public class MyStack {
	Node head;

	public MyStack(Node head) {		// tao constructor  MyStack
		this.head = head;
	}

	public MyStack() {
	}
	
	public void addNode(Product p) {		// ham addNode() them node moi vao MyStack
		Node newNode = new Node(p);
		if(head == null) {
			head = newNode;					// neu stack rong thi gan node head = node moi
		} else {
			newNode.next = head;
			head = newNode; 				// neu khong thi them node moi vao dau danh sach
		}
	}
}	
