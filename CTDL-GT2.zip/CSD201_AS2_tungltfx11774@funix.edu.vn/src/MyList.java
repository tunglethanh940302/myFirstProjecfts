import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MyList {
	Node head;
	Node tail;
	
	
	public MyList(Node head) {						// tao constructor cho MyList
		this.head = head;
	}
	public MyList() {
		
	}
	
	public boolean isEmpty(MyList list) {			// ham isEmpty() kiem tra list co rong hay khong
		if (list.head == null) 
			return true;							// tra ve tru neu rong tra ve false neu khong rong
		return false;
	}
	
	public int length (MyList list) {				// ham length() tra ve do dai cua list
		Node curNode = list.head;
		if (isEmpty(list))							// neu list rong tra ve -1	
			return -1;
		int count = 0;								// khoi tao bien dem count = 0
		while (curNode != null) {				
			count++;								// dung vong lap while duyet tu dau den cuoi list, tang bien dem count + 1 moi lan duyet qua 1 phan tu
			curNode = curNode.next;					// duyet den Node tiep theo	
		}
		return count;								// tra ve count la do dai cua list
	}
	

	public void insertToHead (MyList list, Product item) {		// ham insertToHead() them doi tuong vao dau danh sach
		Node newNode = new Node(item);							// tao node moi
		if (list.head != null) {
			newNode.next = list.head;							// gan node next cua node moi bang node head cua list
		}
		list.head = newNode;									// thay doi head moi
	}
	public Node insertToTail (MyList list, Product item) {		// insertToTail() them phan tu vao cuoi danh sach
		
		Node newNode = new Node(item);							// tao node moi
		if (list.head == null) {								// neu list trong thi gan node moi la node head cua list
			list.head = newNode;
			return list.head;
		}else {
			Node lastNode = list.head;			
			while (lastNode.next != null) {
				lastNode = lastNode.next;						// duyet den cuoi list
			}
			lastNode.next = newNode;							// gan node next cua node cuoi = newNode
		}
		return list.head;										// tra ve node head
	}
	
	
	public void deleteTail (MyList list) {						// ham deleteTail() xoa phan tu cuoi cung trong danh sach
		if (isEmpty(list)) {
			System.out.println("List is empty");				// neu danh sach trong thi hien thi thong bao
		}else {
			Node curNode = list.head;			
			while (curNode.next != null) {
				curNode = curNode.next;							// duyet den cuoi danh sach
			}
			curNode = null;										// gan node cuoi = null
		}
	}	
	
	public void insertAfterPosition (MyList list, int position, Product item) {
		if (position == 0) {
			insertToHead(list, item);
		}else {
			Node newNode = new Node(item);
			Node curNode = this.head;
			int count = 0;
			while (curNode != null) {					// nếu curNode khác null
				count++;								// tăng biến đếm count
				if (count == position) {				// nếu tìm thấy vị trí cần chèn
					newNode.next = curNode.next;		
					curNode.next = newNode;				// đưa newNode vào sau curNode
					break;
				}
				curNode = curNode.next;					// chuyển đến Node tiếp theo
			}
		}
	}
	

	

	 public void removeHead(MyList list) {			// ham removeHead() xoa phan tu dau tien 
		 if (list.head == null) {
			System.out.println("List is empty");	// neu danh sach trong hien thi thong bao
		 }else
			list.head = list.head.next;				// gan node head moi chinh la nut tiep theo
	}
	 
		public void deleteElement(MyList list, Product item) {				// xoa 1 phan tu trong danh sach
			if (list.head == null) {
				System.out.println("List is empty");						// neu danh sach trong hien thi thong bao "list is empty"
			}
			String itemCode = item.getBcode();								// lay thong tin ma ID cua phan tu can xoa
			if (list.head.info.getBcode().compareToIgnoreCase(itemCode) == 0) // so sanh voi phan tu dau tien trong danh sach
				removeHead(list);											// xoa phan tu dau tien
			Node curNode = list.head;
			Node prevNode = null;
			while (curNode != null) {
				if (curNode.info.getBcode().compareToIgnoreCase(itemCode) == 0) {		// so sanh voi cac phan tu con lai
					prevNode.next = curNode.next;										// xoa node hien tai
				}
				prevNode = curNode;
				curNode = curNode.next;
			}
		}	 
	 

	
	public void swap(MyList list,Node firstNode, Node secondNode) {			// ham swap() doi vi tri 2 phan tu
		Node prevFirst = null;
		Node curFirst = list.head;
		String firstId = firstNode.info.getBcode();							// lay ID cua phan tu dau tien
		
		while (curFirst != null) {
			String curFirstId = curFirst.info.getBcode();
			if (firstId.compareToIgnoreCase(curFirstId)==0)					// tro den vi tri cua phan tu dau tien va thoat vong lap
				break;
 			prevFirst = curFirst;
			curFirst = curFirst.next;
		}
		
		String secondId = secondNode.info.getBcode();						// lay ID cua phan tu thu 2 
		Node prevSecond = null;
		Node curSecond = list.head;
		
		while(curSecond != null) {
			String curSecondId = curSecond.info.getBcode();
			if (secondId.compareToIgnoreCase(curSecondId)==0)				// tro den vi tri cua phan tu thu 2 va thoat vong lap
				break;
			prevSecond = curSecond;
			curSecond = curSecond.next;
		}
		
		if (curFirst == null || curSecond == null) 							// neu 1 trong 2 nut ko ton tai thi ket thuc
			return;
		
		if (prevFirst != null)												// neu node phia truoc nut 1 ton tai thi gan node next = nut thu 2
			prevFirst.next = curSecond;
		else 
			list.head = curSecond;											// neu khong ton tai thi gan node head = node thu 2
		
		if (prevSecond != null) 											// neu node phia truoc nut 2 ton tai thi gan node next = nut thu 1
			prevSecond.next = curFirst;
		else 
			list.head = curFirst;											// neu khong ton tai thi gan node head = node thu 1
		
		Node temp = curFirst.next;											// khai bao bien temp
		curFirst.next = curSecond.next;										// hoan doi 2 nut 
		curSecond.next = temp;
	}
	public void addNode(Product info) {										// addNode() them node moi vao danh sach
		if(head == null) {
			head = new Node(info);											// neu danh sach trong thi gan node head = node moi
			return;
		}
		
		Node curNode = head;
		
		while(curNode != null) {
			curNode = curNode.next;
		}
		Node newNode = new Node(info);										// dung vong lap while duyet den cuoi danh sach va gan node moi vao
		curNode.next = newNode;
	}
	

	   

	
	
	
	
}
