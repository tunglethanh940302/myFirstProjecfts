
public class Node {
	Product info;
	Node next;
	public Node(Product info) {		// khoi taoconstructor Node
		this.info = info;
		this.next = null;
	}
	
	
	@Override
	public String toString() {			// ham toString hien thi thong tin cua doi tuong 
		return this.info.toString();
	}
	
}
