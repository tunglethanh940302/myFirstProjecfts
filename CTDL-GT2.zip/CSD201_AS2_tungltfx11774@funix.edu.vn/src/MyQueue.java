
public class MyQueue {
	Node head;

	public MyQueue(Node head) {		// khoi tao constructor
		this.head = head;
	}

	public MyQueue() {
	}
	
	public void addNodeToQueue(Product p) {			// ham addNodeToQueue() them node moi vao queue
		
		Node newNode = new Node(p);
		
		if(head == null) {
			
			head = newNode;							// neu queue rong thi gan node head = node moi
			
		}else {
			
			Node curNode = head;
			
			while(curNode.next != null) {			// dung vong lap while duyet den cuoi queue va them node moi vao cuoi queue
				curNode = curNode.next;
			}
			curNode.next = newNode;
			
		}
		
	}
}
