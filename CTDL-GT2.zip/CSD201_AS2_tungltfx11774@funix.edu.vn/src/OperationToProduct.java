import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Console;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;
import java.util.logging.ConsoleHandler;

public class OperationToProduct {

	public Product createProduct () {												// ham createProduct() tao 1 Product moi
		Scanner sc = new Scanner(System.in);										// tao Scanner sc de lay thong tin nhap vao		
		
		Product newItem  = new Product();
		System.out.print("Input new ID: ");
		newItem.setBcode(sc.nextLine());
		System.out.print("Input Product's Name: ");
		newItem.setTitle(sc.nextLine());
		System.out.print("Input Product's quantity: ");
		newItem.setQuantity(sc.nextInt());
		System.out.print("Input Product's price: ");
		newItem.setPrice(sc.nextDouble());
		System.out.println("\nSuccessfully!\n");
		return newItem;																// tra va Product newItem
	}
	
//	
//	
//	 public int index(Product p, MyList list) {										
//		 
//		 Node curNode = list.head;
//		 int pIndex = 0;
//		 
//		 if (list.head == null) {
//			 return -1;
//		 }else {
//			 while (curNode != null) {
//				 String pCode = p.getBcode();
//				 String curCode = curNode.info.getBcode(); 
//				 if (pCode.compareTo(curCode) == 0) {
//					 break;
//				 }
//				 pIndex++;
//				 curNode = curNode.next;
//			 }
//			 return pIndex;
//		 }
//	 }
//	 
	 public void getAllItemsFromFile(String fileName, MyList list) {						// ham getAllItemsFromFile() doc file va ghi du lieu vao list
		
		 try {																				// su dung try-catch de bat loi thao tac voi file
			
			 File file = new File(fileName);
			 Scanner reader = new Scanner(new FileInputStream(file));
			 
			 while (reader.hasNext()) {
				 
				 Product newProduct = new Product();
				 
				 String newCode = reader.next();
				 newProduct.setBcode(newCode);												// setBcode cho product
				 
				 String del = reader.next();
				 String newName = reader.next();
				 newProduct.setTitle(newName);												// setTitle cho product		
				 
				 del = reader.next();
				 int newQuantity = reader.nextInt();
				 newProduct.setQuantity(newQuantity);										// setQuantity cho Product
				 
				 del = reader.next();
				 double newPrice = reader.nextDouble();
				 newProduct.setPrice(newPrice);												// setPrice cho Product
				 
				 list.head = list.insertToTail(list, newProduct);							// them Product vua tao vao cuoi list
			 }
			 
		} catch (FileNotFoundException fnf) {												// loi file khong ton tai
			fnf.printStackTrace();
		} catch (Exception e) {																// xay ra loi khi doc hoac ghi
			e.printStackTrace();
		}
	 }

		public void displayAll (MyList list) {												// ham displayAll() hien thi list 
			Node curNode = list.head;														
			System.out.println("ID | Title | Quantity | Price");						
			System.out.println("------------------------------");
			if (curNode == null) {															// kiem tra dieu kien neu list rong
				System.out.println("List is empty!");										// xuat ra man hinh thong bao list i empty
			}else {																				
				while (curNode != null) {													// neu list khong rong thi in lan luot tung Node					
					System.out.println(curNode.info.toString());
					curNode = curNode.next;
				}
				System.out.println("\nSuccessfully!\n");
			}
		}	
		public void writeAllItemsToFile (String fileName, MyList list) {					// ham writeAllItemsToFile() luu toan bo list vao file
			
			try {				
				File file = new File(fileName);									
				PrintWriter pw = new PrintWriter(file);										// khoi tao PrintWriter de ghi vao file
				
				Node curNode = list.head;													
				while (curNode != null) {													// chay tu dau list den cuoi list bang vong lap while
					pw.print(curNode + "\n");												// ghi thong tin node curNode vao file
					
					curNode = curNode.next;													// nhay toi node tiep theo	
				}
				System.out.println("\nSuccessfully!\n");
				pw.flush();
				pw.close();
			} catch (FileNotFoundException e) {
				System.out.println("File not found");
			}
		}
	 
		 public void searchByCode(MyList list) {											// ham searchByCode() tim kiem phan tu bang ID
			 Scanner sc = new Scanner(System.in);
			 System.out.print("Input the ID to search: ");									// yeu cau nhap ID va luu vao bien codeName
			 String codeName = sc.nextLine();
			 Node curNode = list.head;
			 
			 if (list.head == null) {														// kiem tra dieu kien list rong 
				 System.out.println("List is empty");
			 } else {
				 boolean isFound = false;													// khai bao bien boolean isFound
				 while (curNode != null) {										
					 String itemCode = curNode.info.getBcode();								// lay thong tin ID cua ncurNode va luu vao bien itemCode
					 
					 if(codeName.compareToIgnoreCase(itemCode) == 0) {						// so sanh ID nguoi dung nhap va ID curNode
						 System.out.println(curNode.info.toString());						// neu giong nhau thi in thong tin curNode		
						 writeNodeToFileAppend("console_output.txt", curNode);				// luu vao file
						 System.out.println("\nSuccessfully!\n");
						 isFound = true;													// gan isFound = true
					 }
					 curNode = curNode.next;
				 }

				 if (isFound == false)														// neu khong tim thay ID thi thong bao ID khong ton tai
					 System.out.println("\nID does not exist\n");
			 }
		 }	
		 public void writeNodeToFileAppend (String fileName, Node node) {					// luu not vao file
				
				try {
					File file = new File(fileName);											
					FileWriter fw = new FileWriter(file,true);								// khoi tao FileWriter voi doi so true cho phep ghi chen vao cuoi file
			        BufferedWriter bw = new BufferedWriter(fw);
			        PrintWriter pw = new PrintWriter(bw);
			        
					pw.append(node+"\n");													// ghi noode vao file
					pw.append("------------------\n");
					pw.flush();
					pw.close();
					
				} catch (FileNotFoundException fnf) {
					System.out.println("File not found");
				} catch (IOException e) {
					System.out.println("Error during reading/writing");
				}
			}
		 		
		 
		 public void deleteByCode(MyList list) {											// xoa phan tu bang ID
			 Scanner sc = new Scanner(System.in);
			 System.out.print("Input the ID to delete: ");									// yeu cau nhap ID tu ban phim
			 String codeName = sc.nextLine();												// luu vao bien codeName
			 Node curNode = list.head;
			 boolean isFound = false;
			 if (list.head == null) {														// kiem tra list co rong khong
				 System.out.println("List is empty");
			 }	
			 while (curNode != null) {
				 String itemCode = curNode.info.getBcode();									// lay thong tin ID cua node	
				 if (codeName.compareToIgnoreCase(list.head.info.getBcode()) == 0) {		// so sanh voi ID nguoi dung nhap
					 list.removeHead(list);													// neu trung voi phan tu head thi xoa head
					 System.out.println("\nSuccessfully!\n");
					 isFound = true;
					 break;
				 }
				 if(codeName.compareToIgnoreCase(itemCode) == 0) {							// xoa phan tu duoc tim thay	
					 list.deleteElement(list, curNode.info);
					 System.out.println("\nSuccessfully!\n");
					 writeNodeToFileAppend("console_output.txt", curNode);
					 isFound = true;
					 break;
				 }
				 curNode = curNode.next;													// chuen toi node tiep theo
			 }
			 if (isFound == false) {
				 System.out.println("\nID does not exist\n");								// thong bao ID khong ton tai neu khong tim thay 
			 }
		 }	 
			public Node paritionLast(Node start, Node end) {
				
			    if(start == end ||  start == null || end == null)
			        return start;
			   
			    Node pivot_prev = start;
			    Node curr = start; 
			    Product pivot = end.info;
			    
			    while(start != end ) {
			        if(start.info.getBcode().compareTo(pivot.getBcode()) < 0) { 
			            pivot_prev = curr; 
			            Product temp = curr.info; 
			            curr.info = start.info; 
			            start.info= temp; 
			            curr = curr.next; 
			        }
			       
			        start = start.next; 
			    }
			       
			    Product temp = curr.info; 
			    curr.info = pivot; 
			    end.info = temp; 
			   
			    return pivot_prev;
			}	 
	 
			public void sortByCode(Node start, Node end) {
				
			    if(start == end )
			        return;
			           
			    Node pivot_prev = paritionLast(start, end);
			   
			    sortByCode(start, pivot_prev);
			       
			    if( pivot_prev != null && pivot_prev == start )
			        sortByCode(pivot_prev.next, end);
			           
			    else if(pivot_prev != null && pivot_prev.next != null)
			        sortByCode(pivot_prev.next.next, end);
			}
				 
			public void convertToBinary(Stack stack, int i) {
				int soDu = 0;
				if(i > 0) {
					soDu = i % 2;
					i=i/2;
					stack.push(soDu + "");
					convertToBinary(stack, i);
				}
			 }
	 
			 public void getAllItemsFromFile(String fileName, MyStack stack) {
				 try {
						
					 File file = new File(fileName);
					 Scanner reader = new Scanner(new FileInputStream(file));
					 
					 while (reader.hasNext()) {
						 
						 Product newProduct = new Product();
						 
						 String newCode = reader.next();
						 newProduct.setBcode(newCode);
						 
						 String del = reader.next();
						 String newName = reader.next();
						 newProduct.setTitle(newName);
						 
						 del = reader.next();
						 int newQuantity = reader.nextInt();
						 newProduct.setQuantity(newQuantity);
						 
						 del = reader.next();
						 double newPrice = reader.nextDouble();
						 newProduct.setPrice(newPrice);
						 
						 stack.addNode(newProduct);
					 }
					 
				} catch (FileNotFoundException fnf) {
					fnf.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			 }	 
	 
			 public void printStack(MyStack stack) {
				
				Node curNode = stack.head;
				if (stack.head == null) {
					System.out.println("Stack is empty");
				}else {
					System.out.println();
					while(curNode != null) {
						System.out.println(curNode.info.toString());
						curNode = curNode.next;
					}
					
					System.out.println("\nSuccessfully!\n");
				}
			 }
			 
			 public void getAllItemsFromFile(String fileName, MyQueue queue) {
				 try {
						
					 File file = new File(fileName);
					 Scanner reader = new Scanner(new FileInputStream(file));
					 
					 while (reader.hasNext()) {
						 
						 Product newProduct = new Product();
						 
						 String newCode = reader.next();
						 newProduct.setBcode(newCode);
						 
						 String del = reader.next();
						 String newName = reader.next();
						 newProduct.setTitle(newName);
						 
						 del = reader.next();
						 int newQuantity = reader.nextInt();
						 newProduct.setQuantity(newQuantity);
						 
						 del = reader.next();
						 double newPrice = reader.nextDouble();
						 newProduct.setPrice(newPrice);
						 
						 queue.addNodeToQueue(newProduct);
					 }
					 
				} catch (FileNotFoundException fnf) {
					fnf.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			 }	 
	 
			 public void printQueue(MyQueue queue) {
				
				Node curNode = queue.head;
				if (queue.head == null) {
					System.out.println("Stack is empty");
				}else {
					System.out.println();
					while(curNode != null) {
						System.out.println(curNode.info.toString());
						curNode = curNode.next;
					}
					
					System.out.println("\nSuccessfully!\n");
				}
			 }			 

			 public void writeStackToFile (String fileName, MyStack stack) {
					
					
					try {
						File file = new File(fileName);
						FileWriter fw = new FileWriter(file,true);
				        BufferedWriter bw = new BufferedWriter(fw);
				        PrintWriter pw = new PrintWriter(bw);
						
						Node curNode = stack.head;
						while (curNode != null) {
							pw.append(curNode + "\n");
							
							curNode = curNode.next;
						}
						pw.append("------------------\n");
						pw.flush();
						pw.close();
					} catch (FileNotFoundException fnf) {
						System.out.println("File not found");
					} catch (IOException e) {
						System.out.println("Error during reading/writing");
					}
				}

			 public void writeQueueToFile (String fileName, MyQueue queue) {
					try {
						File file = new File(fileName);
						FileWriter fw = new FileWriter(file,true);
				        BufferedWriter bw = new BufferedWriter(fw);
				        PrintWriter pw = new PrintWriter(bw);
						
						Node curNode = queue.head;
						while (curNode != null) {
							pw.append(curNode+"\n");
							curNode = curNode.next;
						}
						pw.append("------------------\n");
						pw.flush();
						pw.close();
					} catch (FileNotFoundException fnf) {
						System.out.println("File not found");
					} catch (IOException e) {
						System.out.println("Error during reading/writing");
					}
				}
			 public void writeListToFileAppend (String fileName, MyList list) {
					
					
					try {
						File file = new File(fileName);
						FileWriter fw = new FileWriter(file,true);
				        BufferedWriter bw = new BufferedWriter(fw);
				        PrintWriter pw = new PrintWriter(bw);
						
						Node curNode = list.head;
						while (curNode != null) {
							pw.append(curNode + "\n");
							
							curNode = curNode.next;
						}
						pw.append("------------------\n");
						pw.flush();
						pw.close();
					} catch (FileNotFoundException fnf) {
						System.out.println("File not found");
					} catch (IOException e) {
						System.out.println("Error during reading/writing");
					}
				}
			 			 
			 public void writeStackToFile (String fileName, String str, int quantity) {
					
					try {
						File file = new File(fileName);
						FileWriter fw = new FileWriter(file,true);
				        BufferedWriter bw = new BufferedWriter(fw);
				        PrintWriter pw = new PrintWriter(bw);
						
						pw.append("Quantity=" + quantity + "=>" +"("+str + ")\n");
						pw.append("------------------\n");
						pw.flush();
						pw.close();
					} catch (FileNotFoundException fnf) {
						System.out.println("File not found");
					} catch (IOException e) {
						System.out.println("Error during reading/writing");
					}
				}			 
					 
			public void printStack(Stack stack, int quantity) {
				int n = stack.size();
				
				String binaryNum = "";
				for (int i = 0; i < n; i++) {
					binaryNum = binaryNum + stack.pop();
				}
				System.out.print("Quantity=" + quantity + "=>" +"("+ binaryNum+")\n");
				writeStackToFile("console_output.txt", binaryNum, quantity);
			}		 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
}
