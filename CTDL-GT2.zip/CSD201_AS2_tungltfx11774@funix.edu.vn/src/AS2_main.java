import java.util.Scanner;
import java.util.Stack;

public class AS2_main {
	
	 public static void showMenu() {									// tao ham showMenu 
		   System.out.println("Choose one of this options:");
		   System.out.println("Product list:");
		   System.out.println("1. Load data from file and display");
		   System.out.println("2. Input & add to the end.");
		   System.out.println("3. Display data");
		   System.out.println("4. Save product list to file.");
		   System.out.println("5. Search by ID");
		   System.out.println("6. Delete by ID");
		   System.out.println("7. Sort by ID.");
		   System.out.println("8. Convert to Binary");
		   System.out.println("9. Load to stack and display");
		   System.out.println("10. Load to queue and display.");
		   System.out.println("0. Exit");
		 }

		 
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		OperationToProduct op = new OperationToProduct();				// khoi tao doi tuong OperationToProduct op
		
		MyList myList = new MyList();									// khoi tao myList
		
		do {															// thuc hien vong lap do-while de chay chuong trinh
			showMenu();													// hien thi menu
			choice = sc.nextInt();										// lay thong tin nhap vao cua nguoi dung luu vao bien choice
			switch (choice) {											// xet thong tin nguoi dung nhap vao
			case 1:														// neu choice == 1
				System.out.println();		

				op.getAllItemsFromFile("data.txt", myList);				// goi ham getAllItemsFromFile()
				op.displayAll(myList);									// goi ham displayAll()
				break;
			case 2:														// neu choice == 2		
				Product newProduct = op.createProduct();				// tao 1 Product moi bang ham createProduct()	
				myList.insertToTail(myList, newProduct);				// them Product vua tao vao cuoi list
				break;
			case 3:														// neu choice == 3
				System.out.println();									// goi ham displayAll de hien thi 
				op.displayAll(myList);
				break;
			case 4:														// choice == 4
				op.writeAllItemsToFile("data.txt", myList);				// luu vao file data.txt			
				break;
			case 5:														// choice == 5
				op.searchByCode(myList);								// goi ham searchByCode  de tim kiem	
				break;
			case 6:														// choice == 6
				op.deleteByCode(myList);								// goi ham deleteByCode() de xoa
				break;
			case 7:														// choice == 7
				Node curNode = myList.head;								
				while (curNode.next != null)							// dung vong lap while de chay den cuoi list luu not cuoi cung vao Node curNode	
					curNode = curNode.next;
				
				op.sortByCode(myList.head, curNode);					// goi ham sortByCode() de sap xep 
				op.displayAll(myList);
				op.writeListToFileAppend("console_output.txt", myList);	// ghi vao file console_output.txt
				break;
			case 8:														// choice == 8
				System.out.println();									
				int quantity = myList.head.info.getQuantity();			// lay thong tin quantity cua phan tu dau tien 
				Stack<String> stackChuoi = new Stack<String>();			// khoi tao 1 Stack de luu so nhi phan
				op.convertToBinary(stackChuoi, quantity);				// goi ham convertToBinary()
				
				op.printStack(stackChuoi, quantity);					// hien thi stack
				
				break;
			case 9:														// choice ==9
				MyStack proStack = new MyStack();						
				op.getAllItemsFromFile("data.txt", proStack);			// goi ham getAllItemsFromFile() de doc du lieu tu file data.txt va luu vao stack
				op.printStack(proStack);								// hien thi stack
				op.writeStackToFile("console_output.txt", proStack);	// luu vao file	
				break;
			case 10:													// choice == 10
				MyQueue proQueue = new MyQueue();		
				op.getAllItemsFromFile("data.txt", proQueue);			// doc du lieu tu file data.txt va luu vao Queue
				op.printQueue(proQueue);								// hien thi Queue
				op.writeQueueToFile("console_output.txt", proQueue);	// luu vao file console_output.txt	
				break;

			default:
				break;
			}
			
		}while(choice!=0);
		
	}

}
