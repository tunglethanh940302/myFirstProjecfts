#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

#define PI 3.14159265

float tamGiac[6];
float duongCao[3];
float trungTuyen[3];
float trongTam[2];
float AB,BC,CA,dcA,dcB,dcC,ttA,ttB,ttC,ttX,ttY;


// khoi tao cau truc Point co 2 thanh phan x, y

typedef struct{
    float x, y;
}Point;

Point A, B, C;

// ham tinh khoang cach 2 diem AB

float kc(Point A, Point B){
    return sqrt(pow(B.x-A.x,2)+pow(B.y-A.y,2)); // AB = can bac 2 cua (Bx-Ax)^2 + (By-Ay)^2
};

// ham tinh goc

float gocCanhTamGiac(float AB, float BC, float CA){
    float ret1, ret2, ret3, val, a, b, c;
    val = 180/PI;
    a = BC;
    b = CA;
    c = AB;

    ret1 = acos((pow(b,2)+pow(c,2)-pow(a,2))/(2*b*c)) * val;
    ret2 = acos((pow(a,2)+pow(c,2)-pow(b,2))/(2*a*c)) * val;
    ret3 = acos((pow(a,2)+pow(b,2)-pow(c,2))/(2*a*b)) * val;

    // gan gia tri sau khi tinh toan vao mang tamGiac

    tamGiac[0] = AB;
    tamGiac[1] = BC;
    tamGiac[2] = CA;
    tamGiac[3] = ret1;
    tamGiac[4] = ret2;
    tamGiac[5] = ret3;

    printf("\n\n1. So do co ban cua tam giac ABC");
    printf("\n\n\tChieu dai canh AB la: %.2f\n", c);
    printf("\tChieu dai canh BC la: %.2f\n", a);
    printf("\tChieu dai canh CA la: %.2f\n", b);

    printf("\n\tGoc A la: %.2f\n", ret1);
    printf("\tGoc B la: %.2f\n", ret2);
    printf("\tGoc C la: %.2f\n", ret3);
}



// Kiem tra tam giac
bool kiemTraTamGiac(Point A, Point B, Point C){
    AB = kc(A,B); // do dai canh AB
    BC = kc(B,C); // do dai canh BC
    CA = kc(C,A); // do dai canh CA

    if ((AB < CA + BC) && (CA < AB + BC) && (BC < AB + CA ))  //trong 1 tam giac tong do dai 2 canh luon lon hon do dai canh con lai
       return true;


    return false;

}


//ham xet tam giac

void xetTamGiac(float tamGiac[]){
    float vuong = 90;
    float ret1, ret2, ret3;
    AB = tamGiac[0];
    BC = tamGiac[1];
    CA = tamGiac[2];
    ret1 = tamGiac[3]; // goc A
    ret2 = tamGiac[4]; // goc B
    ret3 = tamGiac[5]; // goc C
    ret1 = round(ret1); // lam tron goc A
    ret2 = round(ret2); // lam tron goc B
    ret3 = round(ret3); // lam tron goc C

    if (ret1 == vuong){
        if (AB == CA)
            printf("\nTam giac ABC vuong can tai A");
        else
            printf("\nTam giac ABC la tam giac vuong tai A");
    } else if (ret2 == vuong){
        if (AB == BC)
            printf("\nTam giac ABC vuong can tai B");
         else
            printf("\nTam giac ABC la tam giac vuong tai B");
    } else if (ret3 == vuong){
        if (BC == CA)
            printf("\nTam giac ABC vuong can tai C");
        else
            printf("\nTam giac ABC la tam giac vuong tai C");
    } else if(ret1>vuong){
        if (AB == CA)
            printf("\nTam giac ABC tu can tai A");
        else
            printf("\nTam giac ABC la tam giac tu tai A");
    } else if(ret2>vuong){
        if (AB == BC)
            printf("\nTam giac ABC tu can tai B");
        else
            printf("\nTam giac ABC la tam giac tu tai B");
    } else if(ret3>vuong){
        if (BC == CA)
            printf("\nTam giac ABC tu can tai C");
        else
            printf("\nTam giac ABC la tam giac tu tai C");
    } else if (AB == BC && AB == CA){
        printf("\nTam giac ABC la tam giac deu");
    } else {
        printf("\nTam giac ABC la tam giac nhon");
    }
}

// ham tinh dien tich tam giac
// cong thuc heron : sqrt(p*(p - AB)*(p - BC)*(p - CA));

float dienTichTamGiac(float tamGiac[]){
    float p;
    AB = tamGiac[0];
    BC = tamGiac[1];
    CA = tamGiac[2];
    p = (AB+BC+CA)/2; // 1/2 chu vi tam giac ABC

    return sqrt(p*(p - AB)*(p - BC)*(p - CA)); // ham tra ve gia tri theo cong thuc heron
}

// ham tinh duong cao tam giac
// S = 1/2 * chieu cao * canh day
// ==> chieu cao == S * 2 / canh day
void duongCaoTamGiac(float tamGiac[]){
    float p,S; // S: dien tich, p : 1/2 chu vi
    AB = tamGiac[0];
    BC = tamGiac[1];
    CA = tamGiac[2];
    p = (AB+BC+CA)/2; // 1/2 chu vi tam giac ABC
    S = sqrt(p*(p - AB)*(p - BC)*(p - CA)); // tinh S theo cong thuc heron
    dcA = S * 2 / BC;  // vi S = 1/2*BC*dcA
    dcB = S * 2 / CA;
    dcC = S * 2 / AB;

    duongCao[0] = dcA; // gan dcA vao mang duongCao
    duongCao[1] = dcB; // gan dcA vao mang duongCao
    duongCao[2] = dcC; // gan dcA vao mang duongCao
    printf("\n\n3. So do nang cao cua tam giac ABC");
    printf("\nDuong cao tu dinh A la : %.2f",dcA);
    printf("\nDuong cao tu dinh B la : %.2f",dcB);
    printf("\nDuong cao tu dinh C la : %.2f",dcC);
}

// ham tinh duong trung tuyen
// ttA^2 = (2(AC^2+AB^2)-BC^2)/4
// ttB^2 = (2(BC^2+AB^2)-CA^2)/4
// ttC^2 = (2(BC^2+CA^2)-AB^2)/4
void trungTuyenTamGiac(float tamGiac[]){
    AB = tamGiac[0];
    BC = tamGiac[1];
    CA = tamGiac[2];
    float mA,mB,mC;
    mA = (2*(pow(CA,2)+pow(AB,2))-pow(BC,2))/4;
    mB = (2*(pow(BC,2)+pow(AB,2))-pow(CA,2))/4;
    mC = (2*(pow(BC,2)+pow(CA,2))-pow(AB,2))/4;
    ttA = sqrt(mA);
    ttB = sqrt(mB);
    ttC = sqrt(mC);
    trungTuyen[0] = ttA;
    trungTuyen[1] = ttB;
    trungTuyen[2] = ttC;

    printf("\n\nDo dai trung tuyen tu dinh A la : %.2f", ttA);
    printf("\nDo dai trung tuyen tu dinh B la : %.2f", ttB);
    printf("\nDo dai trung tuyen tu dinh C la : %.2f", ttC);
}

// ham tinh trong tam tam giac
void trongTamTamGiac(Point A, Point B, Point C){
    ttX = (A.x + B.x + C.x)/3;
    ttY = (A.y + B.y + C.y)/3;

    trongTam[0] = ttX;
    trongTam[1] = ttY;

    printf("\n\n4. Toa do diem dac biet cua tam giac ABC");
    printf("\nToa do trong tam: [%.2f%, %.2f]", ttX, ttY);

}

void giaiMaTamGiac()
{

    printf("Nhap toa do diem A:\nAx: "); scanf("%f",&A.x);
    printf("Ay: "); scanf("%f",&A.y);
    printf("Nhap toa do diem B:\nBx: "); scanf("%f",&B.x);
    printf("By: "); scanf("%f",&B.y);
    printf("Nhap toa do diem C:\nCx: "); scanf("%f",&C.x);
    printf("Cy: ");  scanf("%f",&C.y);

    printf("\nToa do diem A da nhap: A(%.2f,%.2f)\n",A.x,A.y);
    printf("Toa do diem B da nhap: B(%.2f,%.2f)\n",B.x,B.y);
    printf("Toa do diem C da nhap: C(%.2f,%.2f)\n",C.x,C.y);
    printf("-------------------------------\n");

// su dung vong lap while voi dieu kiem 3 diem nhap vao khong tao thanh tam giac

while(kiemTraTamGiac(A, B, C)==false){
    printf("\nToa do 3 diem vua nhap khong tao thanh tam giac.");
    printf("\nNhap lai toa do cac diem A, B, C\n");

    printf("Nhap toa do diem A:\nAx: "); scanf("%f",&A.x);
    printf("Ay: "); scanf("%f",&A.y);
    printf("Nhap toa do diem B:\nBx: "); scanf("%f",&B.x);
    printf("By: "); scanf("%f",&B.y);
    printf("Nhap toa do diem C:\nCx: "); scanf("%f",&C.x);
    printf("Cy: ");  scanf("%f",&C.y);

    printf("\nToa do diem A da nhap: A(%.2f,%.2f)\n",A.x,A.y);
    printf("Toa do diem B da nhap: B(%.2f,%.2f)\n",B.x,B.y);
    printf("Toa do diem C da nhap: C(%.2f,%.2f)\n",C.x,C.y);
    printf("-------------------------------\n");
}

// neu 3 diem nhap vao tao thanh tam giac thi dung vong lap while va xuat ra man hinh

    printf("\nToa do ba diem vua nhap tao thanh tam giac.\n");

    AB = kc(A,B); // do dai canh AB
    BC = kc(B,C); // do dai canh BC
    CA = kc(C,A); // do dai canh CA

    gocCanhTamGiac(AB, BC, CA);

    xetTamGiac(tamGiac);
    printf("\n\n2. Dien tich tam giac ABC");
    printf("\n\nDien tich tam giac ABC la: %.2f",dienTichTamGiac(tamGiac));

    duongCaoTamGiac(tamGiac);
    trungTuyenTamGiac(tamGiac);
    trongTamTamGiac(A, B, C);
    printf("\n");

}

 // thuc thi chuong trinh trong ham main()

int main(){
    giaiMaTamGiac();
    return 0;
}

